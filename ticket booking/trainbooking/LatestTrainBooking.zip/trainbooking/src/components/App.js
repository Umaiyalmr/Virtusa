import React, { Component } from 'react';
import Nav from './Nav'


class App extends Component {
  render() {
    return (
     <div className="container">

    </div>
    );
  }
}

export default App;